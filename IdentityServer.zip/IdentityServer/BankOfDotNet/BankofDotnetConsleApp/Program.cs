﻿using IdentityModel.Client;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.Http;
using System.Text;

namespace BankofDotnetConsleApp
{
    class Program
    {
        public static void Main(string[] args) => MainAsnc().GetAwaiter().GetResult();
            private static async System.Threading.Tasks.Task MainAsnc() {

            var disco = await DiscoveryClient.GetAsync("http://localhost:5000");
            if (disco.IsError)
            {
                Console.WriteLine(disco.Error);
                return;
            }
            var tokenClient = new TokenClient(disco.TokenEndpoint, "client", "secret");
            var tokenResponse = await tokenClient.RequestClientCredentialsAsync("BankofDotNet__API");

            if (tokenResponse.IsError)
            {
                Console.WriteLine(tokenResponse.Error);
                return;
            }
            Console.WriteLine(tokenResponse.Json);
            Console.WriteLine("\n\n");

            //Consume 
            var client = new HttpClient();
            client.SetBearerToken(tokenResponse.AccessToken);
            var customerinfo = new StringContent(
                
                JsonConvert.SerializeObject
                (
                    new {Id=10,FirstName="Test",LastName="tested"}),
                Encoding.UTF8,"application/json"
                );

            var createcustomerResponse = await client.PostAsync("http://localhost:53632/api/customers",customerinfo);

            if (!createcustomerResponse.IsSuccessStatusCode)
            {
                Console.WriteLine(createcustomerResponse);
            }

            var getcustomers = await client.GetAsync("http://localhost:53632/api/customers");

            if (!getcustomers.IsSuccessStatusCode)
            {
                Console.WriteLine(createcustomerResponse);
            }
            else
            {
                var contented = await getcustomers.Content.ReadAsStringAsync();
                Console.WriteLine(JArray.Parse(contented));
                
            }
            Console.Read();
        }
    }
}
